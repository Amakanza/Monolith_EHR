import 'server-only';
import { createClient } from '@/lib/server/supabase/server';

export async function createClinicService(userId: string, name: string, slug: string) {
  const supabase = createClient();
  
  // 1. Create Clinic
  const { data: clinic, error: clinicError } = await supabase
    .from('clinics')
    .insert({ name, slug })
    .select('id')
    .single();

  if (clinicError) throw clinicError;

  // 2. Add Membership (Owner)
  const { error: memberError } = await supabase
    .from('clinic_memberships')
    .insert({
      clinic_id: clinic.id,
      user_id: userId,
      role: 'owner'
    });

  if (memberError) {
    // Cleanup clinic if membership fails (though RLS/transactions should handle this in a real setup)
    await supabase.from('clinics').delete().eq('id', clinic.id);
    throw memberError;
  }

  // 3. Set Active Clinic
  const { error: profileError } = await supabase
    .from('user_profiles')
    .update({ active_clinic_id: clinic.id })
    .eq('id', userId);

  if (profileError) throw profileError;

  return clinic;
}

export async function getClinicDetails(clinicId: string) {
  const supabase = createClient();
  const { data, error } = await supabase
    .from('clinics')
    .select('*')
    .eq('id', clinicId)
    .single();
    
  if (error) throw error;
  return data;
}