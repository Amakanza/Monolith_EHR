export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="text-4xl font-bold tracking-tight">Medical App Scaffold</h1>
      <p className="mt-4 text-lg text-gray-600">Ready for development.</p>
    </main>
  );
}