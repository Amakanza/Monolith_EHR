
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createClinicalNote, finalizeClinicalNote, updateClinicalNote } from '@/lib/services/noteService';

// Mock Auth
vi.mock('@/lib/services/authService', () => ({
  ensureAuthenticatedServer: () => Promise.resolve({ id: 'user1', activeClinicId: 'clinic1' })
}));

// Mock Supabase
const mockInsert = vi.fn();
const mockSelect = vi.fn();
const mockUpdate = vi.fn();
const mockSingle = vi.fn();

const mockSupabase = {
  from: vi.fn(() => ({
    insert: mockInsert,
    select: mockSelect,
    eq: vi.fn(() => ({ select: mockSelect, single: mockSingle })),
    update: mockUpdate,
  })),
};

vi.mock('@/lib/supabase/server', () => ({
  createClient: () => mockSupabase,
}));

describe('Note Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('createClinicalNote creates draft', async () => {
    mockInsert.mockReturnValue({
      select: () => ({ single: () => Promise.resolve({ data: { id: 'n1', status: 'draft' }, error: null }) })
    });

    const result = await createClinicalNote({
      clinicId: 'clinic1',
      patientId: 'p1',
      title: 'Test',
      noteDate: '2024-01-01'
    });

    expect(result.note.status).toBe('draft');
    expect(mockInsert).toHaveBeenCalledWith(expect.objectContaining({ status: 'draft' }));
  });

  it('updateClinicalNote throws if finalized', async () => {
    // Mock fetching existing note returning 'final'
    mockSelect.mockReturnValue({
       eq: () => ({ single: () => Promise.resolve({ data: { status: 'final' }, error: null }) })
    });

    await expect(updateClinicalNote('n1', { title: 'New' })).rejects.toThrow('NOTE_FINALIZED');
  });

  it('finalizeClinicalNote updates status', async () => {
    mockSelect.mockReturnValue({
       eq: () => ({ single: () => Promise.resolve({ data: { status: 'draft' }, error: null }) })
    });
    mockUpdate.mockReturnValue({
       eq: () => ({ select: () => ({ single: () => Promise.resolve({ data: { id: 'n1', status: 'final' }, error: null }) }) })
    });

    const result = await finalizeClinicalNote('n1');
    expect(mockUpdate).toHaveBeenCalledWith(expect.objectContaining({ status: 'final' }));
  });
});
