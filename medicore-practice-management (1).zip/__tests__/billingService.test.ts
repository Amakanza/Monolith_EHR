
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createInvoice, addInvoiceItem, createPayment } from '@/lib/services/billingService';

// Mock Auth
vi.mock('@/lib/services/authService', () => ({
  ensureAuthenticatedServer: () => Promise.resolve({ id: 'user1', activeClinicId: 'clinic1' })
}));

// Mock Supabase
const mockRpc = vi.fn();
const mockInsert = vi.fn();
const mockSelect = vi.fn();
const mockUpdate = vi.fn();
const mockSingle = vi.fn();
const mockEq = vi.fn();

const mockSupabase = {
  rpc: mockRpc,
  from: vi.fn(() => ({
    insert: mockInsert,
    select: mockSelect,
    eq: mockEq,
    update: mockUpdate,
  })),
};

vi.mock('@/lib/supabase/server', () => ({
  createClient: () => mockSupabase,
}));

describe('Billing Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('createInvoice generates number and creates invoice', async () => {
    mockRpc.mockResolvedValue({ data: 'INV-000001', error: null });
    // Mock membership fetch (null)
    mockSelect.mockReturnValue({
       eq: () => ({ single: () => Promise.resolve({ data: null, error: null }) })
    });
    // Mock invoice insert
    mockInsert.mockReturnValue({
       select: () => ({ single: () => Promise.resolve({ data: { id: 'inv1', invoice_number: 'INV-000001' }, error: null }) })
    });

    const result = await createInvoice({ patientId: 'p1', clinicId: 'clinic1' });
    expect(mockRpc).toHaveBeenCalledWith('generate_invoice_number', { _clinic_id: 'clinic1' });
    expect(result.invoice.invoiceNumber).toBe('INV-000001');
  });

  it('addInvoiceItem adds item and recalculates totals', async () => {
    // Mock getting invoice status
    mockSelect.mockReturnValueOnce({
      eq: () => ({ single: () => Promise.resolve({ data: { id: 'inv1', clinic_id: 'c1', status: 'draft', tax_rate: 10 }, error: null }) })
    });
    
    // Mock insert item
    mockInsert.mockReturnValue({
       select: () => ({ single: () => Promise.resolve({ data: { id: 'item1', line_subtotal_cents: 1000 }, error: null }) })
    });

    // Mock recalculation queries
    // Sum Items
    mockSelect.mockReturnValueOnce({ eq: () => Promise.resolve({ data: [{ line_subtotal_cents: 1000 }], error: null }) });
    // Sum Payments
    mockSelect.mockReturnValueOnce({ eq: () => Promise.resolve({ data: [], error: null }) });
    // Get Tax Rate (again, for recalc)
    mockSelect.mockReturnValueOnce({
      eq: () => ({ single: () => Promise.resolve({ data: { id: 'inv1', status: 'draft', tax_rate: 10 }, error: null }) })
    });

    // Mock update invoice
    mockUpdate.mockReturnValue({
       eq: () => Promise.resolve({})
    });

    await addInvoiceItem('inv1', { description: 'Test', quantity: 1, unitPriceCents: 1000 });
    
    // Expect update to be called with calculated values: 
    // Subtotal: 1000. Tax (10%): 100. Total: 1100. Balance: 1100.
    expect(mockUpdate).toHaveBeenCalledWith(expect.objectContaining({
       subtotal_cents: 1000,
       tax_cents: 100,
       total_cents: 1100,
       balance_due_cents: 1100
    }));
  });
});
