import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createClinic, listMyClinics } from '@/lib/services/clinicService';

// Mock Supabase
const mockRpc = vi.fn();
const mockFrom = vi.fn();
const mockSelect = vi.fn();

vi.mock('@/lib/supabase/server', () => ({
  createClient: () => ({
    rpc: mockRpc,
    from: mockFrom,
  }),
}));

describe('Clinic Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('createClinic calls RPC and returns mapped clinic', async () => {
    mockRpc.mockResolvedValue({
      data: {
        id: 'c1',
        name: 'Test Clinic',
        timezone: 'UTC',
        created_by: 'u1',
        created_at: '2024-01-01',
        updated_at: '2024-01-01'
      },
      error: null
    });

    const result = await createClinic({ name: 'Test Clinic' });
    
    expect(mockRpc).toHaveBeenCalledWith('create_clinic_with_owner', {
      name: 'Test Clinic',
      timezone: 'Africa/Windhoek'
    });
    expect(result.clinic.name).toBe('Test Clinic');
    expect(result.clinic.id).toBe('c1');
  });

  it('listMyClinics returns list of clinics', async () => {
    mockFrom.mockReturnValue({
      select: () => ({
        order: mockSelect
      })
    });
    mockSelect.mockResolvedValue({
      data: [
        { id: 'c1', name: 'A', timezone: 'UTC' },
        { id: 'c2', name: 'B', timezone: 'UTC' }
      ],
      error: null
    });

    const result = await listMyClinics();
    expect(result.clinics).toHaveLength(2);
    expect(result.clinics[0].name).toBe('A');
  });
});
