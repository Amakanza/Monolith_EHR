
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createAppointment, listAppointments } from '@/lib/services/appointmentService';

// Mock Auth
vi.mock('@/lib/services/authService', () => ({
  ensureAuthenticatedServer: () => Promise.resolve({ id: 'user1', activeClinicId: 'clinic1' })
}));

// Mock Supabase
const mockInsert = vi.fn();
const mockSelect = vi.fn();
const mockEq = vi.fn();
const mockSingle = vi.fn();
const mockGte = vi.fn();

const mockSupabase = {
  from: vi.fn(() => ({
    insert: mockInsert,
    select: mockSelect,
    eq: mockEq,
    update: vi.fn(() => ({ eq: vi.fn(() => ({ select: vi.fn(() => ({ single: vi.fn() })) })) })),
    order: vi.fn(() => ({ eq: mockEq, gte: mockGte })),
  })),
};

vi.mock('@/lib/supabase/server', () => ({
  createClient: () => mockSupabase,
}));

describe('Appointment Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockInsert.mockReset();
    mockSelect.mockReset();
  });

  it('createAppointment success', async () => {
    mockInsert.mockReturnValue({
      select: () => ({ single: () => Promise.resolve({ data: { id: 'a1', status: 'booked' }, error: null }) })
    });

    const result = await createAppointment({
      clinicId: 'clinic1',
      patientId: 'p1',
      clinicianId: 'c1',
      startTime: '2024-01-01T10:00:00Z',
      endTime: '2024-01-01T10:30:00Z'
    });

    expect(result.appointment.id).toBe('a1');
    expect(mockSupabase.from).toHaveBeenCalledWith('appointments');
  });

  it('createAppointment handles overlap error', async () => {
    // Mock DB overlap error 23P01
    mockInsert.mockReturnValue({
      select: () => ({ single: () => Promise.resolve({ data: null, error: { code: '23P01', message: 'Exclude violation' } }) })
    });

    await expect(createAppointment({
      clinicId: 'clinic1',
      patientId: 'p1',
      clinicianId: 'c1',
      startTime: '2024-01-01T10:00:00Z',
      endTime: '2024-01-01T10:30:00Z'
    })).rejects.toThrow('APPOINTMENT_OVERLAP');
  });

  it('createAppointment validates time', async () => {
    await expect(createAppointment({
      patientId: 'p1',
      clinicianId: 'c1',
      startTime: '2024-01-01T11:00:00Z',
      endTime: '2024-01-01T10:00:00Z' // Invalid
    })).rejects.toThrow('End time must be after start time');
  });
});
