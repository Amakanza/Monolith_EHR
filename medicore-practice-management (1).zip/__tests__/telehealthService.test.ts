
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createTelehealthSession, validatePatientJoin } from '@/lib/services/telehealthService';

// Mock Auth
vi.mock('@/lib/services/authService', () => ({
  ensureAuthenticatedServer: () => Promise.resolve({ id: 'user1', activeClinicId: 'clinic1' })
}));

// Mock Supabase
const mockInsert = vi.fn();
const mockSelect = vi.fn();
const mockSingle = vi.fn();

const mockSupabase = {
  from: vi.fn(() => ({
    select: mockSelect,
    eq: vi.fn(() => ({ eq: vi.fn(() => ({ single: mockSingle, maybeSingle: mockSingle })), single: mockSingle })),
    insert: mockInsert,
  })),
};

vi.mock('@/lib/supabase/server', () => ({
  createClient: () => mockSupabase,
}));

// Mock Supabase JS for service client in validatePatientJoin
vi.mock('@supabase/supabase-js', () => ({
  createClient: () => mockSupabase,
}));

describe('Telehealth Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('createTelehealthSession generates token if enabled', async () => {
    // Mock Appointment
    mockSingle.mockResolvedValueOnce({ data: { patient_id: 'p1', clinician_id: 'c1' }, error: null });
    // Mock Insert
    mockInsert.mockReturnValue({
      select: () => ({ single: () => Promise.resolve({ data: { id: 's1', patient_join_token: 'abc' }, error: null }) })
    });

    const result = await createTelehealthSession({
      appointmentId: 'appt1',
      provider: 'google_meet',
      joinUrl: 'http://meet',
      patientJoinEnabled: true
    });

    expect(mockInsert).toHaveBeenCalledWith(expect.objectContaining({
      patient_join_token: expect.any(String)
    }));
  });

  it('validatePatientJoin validates token and logs success', async () => {
    // Mock Session Fetch
    mockSingle.mockResolvedValueOnce({ 
      data: { id: 's1', clinic_id: 'c1', is_active: true, status: 'scheduled', join_url: 'http://meet' }, 
      error: null 
    });
    // Mock Log Insert
    mockInsert.mockResolvedValue({ error: null });

    const result = await validatePatientJoin('validToken', 'Mozilla');
    
    expect(result.joinUrl).toBe('http://meet');
    expect(mockInsert).toHaveBeenCalledWith(expect.objectContaining({
      status: 'success',
      actor_type: 'patient'
    }));
  });

  it('validatePatientJoin throws on inactive session', async () => {
    mockSingle.mockResolvedValueOnce({ 
      data: { id: 's1', clinic_id: 'c1', is_active: false, status: 'scheduled' }, 
      error: null 
    });

    await expect(validatePatientJoin('token')).rejects.toThrow('SESSION_INACTIVE');
    expect(mockInsert).toHaveBeenCalledWith(expect.objectContaining({ status: 'denied' }));
  });
});
