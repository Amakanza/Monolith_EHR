
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { queueAppointmentReminder, markMessageSent } from '@/lib/services/communicationsService';

// Mock Auth
vi.mock('@/lib/services/authService', () => ({
  ensureAuthenticatedServer: () => Promise.resolve({ id: 'user1', activeClinicId: 'clinic1' })
}));

// Mock Supabase
const mockInsert = vi.fn();
const mockSelect = vi.fn();
const mockUpdate = vi.fn();
const mockSingle = vi.fn();
const mockEq = vi.fn();

const mockSupabase = {
  from: vi.fn(() => ({
    insert: mockInsert,
    select: mockSelect,
    eq: mockEq,
    update: mockUpdate,
  })),
};

vi.mock('@/lib/supabase/server', () => ({
  createClient: () => mockSupabase,
}));

describe('Communications Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('markMessageSent updates status and timestamp', async () => {
    mockUpdate.mockReturnValue({
      eq: () => ({ select: () => ({ single: () => Promise.resolve({ data: { id: 'm1', status: 'sent' }, error: null }) }) })
    });

    const result = await markMessageSent('m1');
    expect(result.message.status).toBe('sent');
    expect(mockUpdate).toHaveBeenCalledWith(expect.objectContaining({ status: 'sent' }));
  });

  it('queueAppointmentReminder fetches appointment and queues message', async () => {
    // Mock Appointment Fetch
    mockSelect.mockReturnValue({
      eq: () => ({ 
        single: () => Promise.resolve({ 
          data: { 
            id: 'appt1', 
            clinic_id: 'c1', 
            patient_id: 'p1', 
            start_time: '2024-01-02T10:00:00Z', 
            patients: { first_name: 'John', cell_number: '123456789' } 
          }, 
          error: null 
        }) 
      })
    });

    // Mock Message Insert
    mockInsert.mockReturnValue({}); // No return needed for void helper unless we mock implementation detail

    await queueAppointmentReminder({ appointmentId: 'appt1' });

    expect(mockInsert).toHaveBeenCalledWith(expect.objectContaining({
      clinic_id: 'c1',
      recipient_contact: '123456789',
      channel: 'sms',
      send_after_event: 'appointment_booked'
    }));
  });
});
