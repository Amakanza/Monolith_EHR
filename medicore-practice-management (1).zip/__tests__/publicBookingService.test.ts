
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { getAvailability, submitBooking } from '@/lib/services/publicBookingService';

// Mocks
const mockSelect = vi.fn();
const mockInsert = vi.fn();
const mockUpdate = vi.fn();
const mockSingle = vi.fn();
const mockEq = vi.fn();

// Mock Admin Client
const mockSupabase = {
  from: vi.fn(() => ({
    select: mockSelect,
    eq: mockEq,
    single: mockSingle,
    insert: mockInsert,
    update: mockUpdate,
    in: vi.fn(() => ({ select: mockSelect, eq: mockEq })), // for chaining
    gte: vi.fn(() => ({ lte: vi.fn(() => Promise.resolve({ data: [] })) })), // for availability fetch
    lt: vi.fn(),
    gt: vi.fn(),
    neq: vi.fn(() => ({ neq: vi.fn(() => ({ gte: vi.fn(() => ({ lte: vi.fn(() => Promise.resolve({ data: [] })) })) })) })),
  })),
};

vi.mock('@/lib/supabase/admin', () => ({
  createAdminClient: () => mockSupabase
}));

describe('Public Booking Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockEq.mockReturnValue({
      eq: mockEq,
      single: mockSingle,
      select: mockSelect,
      in: vi.fn(() => ({ select: mockSelect })),
    });
  });

  it('submitBooking rejects honeypot spam', async () => {
    const result = await submitBooking('slug', { honeypot: 'spam' } as any, { ip: '1.1.1.1', userAgent: 'bot' });
    expect(result.success).toBe(false);
    expect(result.message).toContain('Spam');
  });

  it('getAvailability returns slots', async () => {
    // Mock Profile
    mockSingle.mockResolvedValueOnce({ data: { clinic_id: 'c1', timezone: 'UTC' }, error: null });
    // Mock Duration
    mockSingle.mockResolvedValueOnce({ data: { default_duration_minutes: 30 }, error: null });
    // Mock Clinicians
    mockSelect.mockResolvedValueOnce({ data: [{ user_id: 'u1' }], error: null }); // from 'clinic_memberships'
    // Mock Appointments (Empty)
    // The query chain is complex to mock perfectly with simple jest fns, 
    // but we can mock the final promise resolution of the appointments query.
    // We adjusted the mockSupabase above to return empty array for the availability query chain.

    const slots = await getAvailability('test-slug', '2024-01-01', 'type1');
    expect(slots.length).toBeGreaterThan(0);
    expect(slots[0].startTime).toContain('08:00');
  });
});
