import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createPatient, listPatients, upsertPatientMembership } from '@/lib/services/patientService';

// Mock Auth
vi.mock('@/lib/services/authService', () => ({
  ensureAuthenticatedServer: () => Promise.resolve({ id: 'user1', activeClinicId: 'clinic1' })
}));

// Mock Supabase
const mockInsert = vi.fn();
const mockSelect = vi.fn();
const mockEq = vi.fn();
const mockSingle = vi.fn();

const mockSupabase = {
  from: vi.fn(() => ({
    insert: mockInsert,
    select: mockSelect,
    eq: mockEq,
    update: vi.fn(() => ({ eq: vi.fn(() => ({ select: vi.fn(() => ({ single: vi.fn() })) })) })),
    upsert: vi.fn(() => ({ onConflict: vi.fn(() => ({ select: vi.fn(() => ({ single: mockSingle })) })) })),
    order: vi.fn(() => ({ order: vi.fn(() => Promise.resolve({ data: [], error: null })) })),
    is: vi.fn(() => Promise.resolve({ data: [], error: null }))
  })),
};

vi.mock('@/lib/supabase/server', () => ({
  createClient: () => mockSupabase,
}));

describe('Patient Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('createPatient inserts patient and membership', async () => {
    // Setup Mocks
    mockInsert.mockReturnValue({
      select: () => ({ single: () => Promise.resolve({ data: { id: 'p1' }, error: null }) })
    });

    const result = await createPatient({
      clinicId: 'clinic1',
      patient: { firstName: 'John', lastName: 'Doe' },
      membership: {
        patientIsMainMember: true,
        fundingType: 'cash'
      }
    });

    // Check patient insert
    expect(mockSupabase.from).toHaveBeenCalledWith('patients');
    expect(mockInsert).toHaveBeenCalledWith(expect.objectContaining({ first_name: 'John' }));

    // Check membership insert
    expect(mockSupabase.from).toHaveBeenCalledWith('patient_membership');
    expect(mockInsert).toHaveBeenCalledWith(expect.objectContaining({ patient_id: 'p1', funding_type: 'cash' }));
  });

  it('createPatient fails validation if not main member and missing details', async () => {
    await expect(createPatient({
      clinicId: 'clinic1',
      patient: { firstName: 'Child', lastName: 'Doe' }, // Missing dependentCode
      membership: {
        patientIsMainMember: false,
        fundingType: 'medical_aid'
      }
    })).rejects.toThrow('Dependent Code is required');
  });

  it('upsertPatientMembership validates dependent code from DB', async () => {
    // Mock fetching patient
    mockSelect.mockReturnValue({
       eq: () => ({ single: () => Promise.resolve({ data: { clinic_id: 'c1', dependent_code: null }, error: null }) })
    });

    await expect(upsertPatientMembership('p1', {
      patientIsMainMember: false,
      fundingType: 'medical_aid'
    })).rejects.toThrow('Dependent Code is required');
  });
});
