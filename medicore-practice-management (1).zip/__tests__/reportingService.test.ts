
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { getClinicDashboard, recordAuditEvent, exportPatientsCsv } from '@/lib/services/reportingService';

// Mock Auth
vi.mock('@/lib/services/authService', () => ({
  ensureAuthenticatedServer: () => Promise.resolve({ id: 'user1', activeClinicId: 'clinic1' }),
  getCurrentUserServer: () => Promise.resolve({ id: 'user1' })
}));

// Mock Supabase
const mockSelect = vi.fn();
const mockInsert = vi.fn();
const mockEq = vi.fn();
const mockLte = vi.fn();
const mockGte = vi.fn();

const mockSupabase = {
  from: vi.fn(() => ({
    select: mockSelect,
    insert: mockInsert,
    eq: mockEq,
    lte: mockLte,
    gte: mockGte,
    is: vi.fn(() => Promise.resolve({ count: 10 })),
    order: vi.fn(() => ({ data: [], error: null })) // for exports
  })),
};

vi.mock('@/lib/supabase/server', () => ({
  createClient: () => mockSupabase,
}));

describe('Reporting Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockSelect.mockReset();
    mockEq.mockReturnValue({ gte: mockGte });
    mockGte.mockReturnValue({ lte: mockLte });
    mockLte.mockResolvedValue({ count: 5, data: [] });
  });

  it('recordAuditEvent calls insert on audit_events', async () => {
    mockInsert.mockResolvedValue({ error: null });
    
    await recordAuditEvent({
      clinicId: 'c1',
      eventType: 'test.event',
      entityType: 'test',
      entityId: '123'
    });

    expect(mockSupabase.from).toHaveBeenCalledWith('audit_events');
    expect(mockInsert).toHaveBeenCalledWith(expect.objectContaining({
      event_type: 'test.event',
      actor_user_id: 'user1'
    }));
  });

  it('getClinicDashboard aggregates metrics', async () => {
    // Setup mocks for multiple calls
    // 1. active patients
    mockSelect.mockReturnValueOnce({ eq: () => ({ is: () => Promise.resolve({ count: 100 }) }) });
    // 2. new patients
    mockSelect.mockReturnValueOnce({ eq: () => ({ gte: () => ({ lte: () => Promise.resolve({ count: 5 }) }) }) });
    // 3. appointments
    mockSelect.mockReturnValueOnce({ eq: () => ({ gte: () => ({ lte: () => Promise.resolve({ data: [{status: 'booked'}, {status: 'completed'}] }) }) }) });
    // 4. notes
    mockSelect.mockReturnValueOnce({ eq: () => ({ gte: () => ({ lte: () => Promise.resolve({ count: 3 }) }) }) });
    // 5. invoices
    mockSelect.mockReturnValueOnce({ eq: () => ({ gte: () => ({ lte: () => ({ neq: () => Promise.resolve({ data: [{total_cents: 1000, amount_paid_cents: 500, balance_due_cents: 500}] }) }) }) }) });

    const result = await getClinicDashboard({ clinicId: 'clinic1' });
    
    expect(result.metrics.activePatients).toBe(100);
    expect(result.metrics.newPatientsInRange).toBe(5);
    expect(result.metrics.appointmentsByStatus.booked).toBe(1);
    expect(result.metrics.invoicesTotals.totalCents).toBe(1000);
  });

  it('exportPatientsCsv returns valid csv string', async () => {
    mockSelect.mockReturnValue({ 
      eq: () => ({ 
        order: () => Promise.resolve({ 
          data: [{ id: 'p1', first_name: 'John', last_name: 'Doe' }], 
          error: null 
        }) 
      }) 
    });

    const result = await exportPatientsCsv({ clinicId: 'clinic1' });
    expect(result.csv).toContain('First Name,Last Name');
    expect(result.csv).toContain('John,Doe');
  });
});
